

typedef struct NO *ArvBin;

typedef struct NO *arvAVL;

ArvBin *cria_arvAVL();

void liberar_arvAVL(ArvBin *raiz);

int vazia_arvAVL(ArvBin *raiz);

int altura_arvAVL(ArvBin *raiz);

int totalNO_arvAVL(ArvBin *raiz);

void preOrdem_arvAVL(ArvBin *raiz);

void emOrdem_arvAVL(ArvBin *raiz);

void posOrdem_arvAVL(ArvBin *raiz);

int insere_arvAVL(arvAVL *raiz, int valor);

int remove_arvAVL(arvAVL *raiz, int valor);

int consulta_arvAVL(ArvBin *raiz, int valor);

